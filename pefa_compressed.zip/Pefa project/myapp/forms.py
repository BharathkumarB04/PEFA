from django import forms
from .models import *
class Expenseform(forms.ModelForm):
    class Meta:
        model = Expense
        fields = ['title','amount','date','uploaded_bill']
        widgets ={
            'title': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter the title expense'
            }),
            'amount': forms.NumberInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter the amount'
            }),
            'date': forms.DateInput(attrs={
                'class': 'form-control',
                'type': 'date'
            }),
            'uploaded_bill': forms.ClearableFileInput(attrs={
                'class': 'form-control-file'
            }),
        }

from django import forms
from .models import MonthlyBudget

class MonthlyBudgetForm(forms.ModelForm):
    class Meta:
        model = MonthlyBudget
        fields = ['category', 'amount', 'year', 'month']
        widgets = {
            'category': forms.TextInput(attrs={'class': 'form-control'}),
            'amount': forms.NumberInput(attrs={'class': 'form-control'}),
            'year': forms.NumberInput(attrs={'class': 'form-control'}),
            'month': forms.NumberInput(attrs={'class': 'form-control'}),
        }
class SaveMoneyForm(forms.Form):
    goal_id = forms.IntegerField(widget=forms.HiddenInput())
    save_amount = forms.DecimalField(max_digits=10, decimal_places=2, min_value=0)
