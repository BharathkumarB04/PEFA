from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
from .models import Expense
from django.http import HttpResponseRedirect
from django.db import models
from .forms import *
from .models import *
from django.contrib import messages
from django.db.models import Sum
from datetime import datetime
# Create your views here.

def login_view(request):
    if request.method == "POST":
        username = request.POST['username']
        pwd = request.POST['password']
        remember_me = request.POST.get('remember_me', False)
        user = authenticate(request, username=username, password=pwd)
        print(user, username, pwd)
        if user is not None:
            login(request, user)
            if not remember_me:
                request.session.set_expiry(0)
            else:
                request.session.set_expiry(1209600)
            return redirect('home/')
        else:
            context={
                'error': '**Invalid username or password',
            }
            return render(request, 'login.html', context)

    return render(request, 'login.html')

def logout_view(request):
    logout(request)
    return redirect('/')

def signup_view(request):
    if request.method == "POST":
            username = request.POST['username']
            email = request.POST['email']
            password = request.POST['password']
            cpassword = request.POST['cpassword']
            if User.objects.filter(username=username).exists():
                context={
                    'user_error': '**Username already exists'
                }
                return render(request, 'register.html', context)
            if password != cpassword:
                context={
                    'pass_error': '**Passwords do not match'
                }
                return render(request, 'register.html', context)
            
            User.objects.create_user(username = username, email = email, password = cpassword)
            return redirect('/')

    return render(request, 'register.html')

@login_required
def home(request):
    expenses =Expense.objects.filter(user=request.user)
    total_transactions=expenses.count()
    total_expense = expenses.aggregate(total=models.Sum('amount'))['total'] or 0
    Budget = MonthlyBudget.objects.filter(user=request.user).order_by('-year','-month').first()
    s_budget = Budget.amount if Budget else 0
    sum_budget = MonthlyBudget.objects.filter(user=request.user).order_by('-year','-month')
    budgets = sum_budget.aggregate(budgets=Sum('amount'))['budgets'] or 0
    balance = budgets-total_expense
    return render(request, 'dashboard.html', {'expenses': expenses, 'total_transactions': total_transactions, 'total_expense': total_expense, 'total_budget': s_budget , 'balance': balance})
    

def forget_view(request):
    if request.method=='POST':
        email = request.POST['email']
        password = request.POST['npassword']
        user = User.objects.get(email=email)
        user.set_password(password)
        user.save()
        return redirect('/')
    return render(request, 'forget.html')

@login_required
def transaction(request):
    if request.method == 'POST':
        form = Expenseform(request.POST, request.FILES)
        if form.is_valid():
            expense = form.save(commit=False)
            expense.user = request.user
            expense.save()
            messages.success(request, 'Expense added successfully')
            return HttpResponseRedirect(request.META.get('HTTP_REFERER'))
            
    else:
        form = Expenseform()
        return render(request, 'transaction.html', {'form': form})

@login_required
def delete_expense(request, expense_id):
    expense = get_object_or_404(Expense, id=expense_id, user=request.user)
    expense.delete()
    return HttpResponseRedirect(request.META.get('HTTP_REFERER'))

@login_required
def sip_calc(request):
    return render(request, 'SIP_calc.html')

@login_required
def loan_calc(request):
    return render(request, 'loan.html')
    
@login_required
def savings_goal_manager(request):
    if request.method == 'POST':
        form = SaveMoneyForm(request.POST)
        if form.is_valid():
            goal_id = form.cleaned_data['goal_id']
            save_amount = form.cleaned_data['save_amount']

            goal = get_object_or_404(SavingsGoal, id=goal_id, user=request.user)
            if goal.remaining_amount >= save_amount:
                # Update the goal with the saved amount
                goal.current_amount += save_amount
                goal.save()

                # Create an expense for the saving action
                Expense.objects.create(
                    user=request.user,
                    amount=save_amount,
                    category='Savings',
                    description=f'Savings goal: {goal.goal_name}'
                )

                messages.success(request, f'You have successfully saved ${save_amount} towards your goal.')
            else:
                messages.error(request, f'The amount exceeds the remaining balance for this goal.')

            return HttpResponseRedirect(reverse('savings_goal_manager'))

    else:
        form = SaveMoneyForm()

    # Fetch all the goals and expenses of the logged-in user
    goals = SavingsGoal.objects.filter(user=request.user)
    expenses = Expense.objects.filter(user=request.user)

    return render(request, 'savings.html', {
        'form': form,
        'goals': goals,
        'expenses': expenses
    })

@login_required
def budget_management(request):
    # Get all budgets for the current user
    budgets = MonthlyBudget.objects.filter(user=request.user)
    
    if request.method == 'POST':
        form = MonthlyBudgetForm(request.POST)
        if form.is_valid():
            budget = form.save(commit=False)
            budget.user = request.user  # Assign the logged-in user
            budget.save()
            messages.success(request, 'Budget added successfully!')
            return redirect('budget_management')
    else:
        form = MonthlyBudgetForm()

    return render(request, 'budget.html', {'form': form, 'budgets': budgets})

@login_required
def delete_budget(request, budget_id):
    # Get the budget to delete
    budget = get_object_or_404(MonthlyBudget, id=budget_id, user=request.user)
    budget.delete()
    messages.success(request, 'Budget deleted successfully!')
    return redirect('budget_management')