from django.urls import path
from . import views
urlpatterns = [
    path('',views.login_view, name='login_view'),
    path('logout/', views.logout_view, name='logout_view'),
    path('signup/', views.signup_view, name='signup_view'),
    path('forget/', views.forget_view, name='forget_view'),
    path('home/', views.home, name='home'),
    path('transaction/', views.transaction, name='transaction'),
    path('Sip/',views.sip_calc, name ='sip_calc'),
    path('loan/', views.loan_calc, name='loan_calc' ),
    path('delete-expense/<int:expense_id>/', views.delete_expense, name='delete_expense'),
    path('budget/', views.budget_management, name='budget_management'),
    path('budget/delete/<int:budget_id>/', views.delete_budget, name='delete_budget'),
    path('savings-goals/', views.savings_goal_manager, name='savings_goal_manager'),
]
